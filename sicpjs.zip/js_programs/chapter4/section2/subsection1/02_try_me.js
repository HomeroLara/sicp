// chapter=2 variant=lazy 
// Source Academy opens this program
// in lazy mode. Choose "Source §2" to
// to compare with strict mode
function try_me(a, b) {
    return a === 0 ? 1 : b;	
}

try_me(0, head(null));

// expected: 1
