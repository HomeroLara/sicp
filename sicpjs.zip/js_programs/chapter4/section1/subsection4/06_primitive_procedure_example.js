const my_primitive_plus =
    list("primitive", (x, y) => x + y );
primitive_implementation(my_primitive_plus);
is_primitive_function(my_primitive_plus);
