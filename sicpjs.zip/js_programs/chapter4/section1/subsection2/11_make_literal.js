function make_literal(value) {
    return list("literal", value);
}
