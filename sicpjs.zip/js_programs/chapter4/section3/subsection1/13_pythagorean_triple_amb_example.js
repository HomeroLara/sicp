a_pythogorean_triple_between(5, 15);
// Press "Run" for the first solution. Type
// retry
// in the REPL on the right, for more solutions
