const x = an_integer_starting_from(1);
require(x >= 4.5);
x;
// Press "Run" for the first solution. Type
// retry
// in the REPL on the right, for more solutions
