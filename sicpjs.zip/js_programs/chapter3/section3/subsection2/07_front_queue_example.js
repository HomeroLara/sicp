const q = pair(pair(1, 2), 3);
front_queue(q);
