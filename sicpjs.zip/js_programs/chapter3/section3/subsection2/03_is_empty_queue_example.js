const q = pair(null, 2);
is_empty_queue(q);
