const s = make_monitored(math_sqrt);
s(100);
s("how many calls");
s(5);
s("how many calls");
