(amount => 25 - amount)(20)
